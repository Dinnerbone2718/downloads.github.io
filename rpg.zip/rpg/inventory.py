import pygame

width = 1920
height = 1080

pygame.init()

screen = pygame.display.set_mode((width,height))
clock = pygame.time.Clock()


prefix = ""

def draw_text(text, text_col, x, y, size=100):
    font = pygame.font.Font(f"{prefix}assets/8bitOperatorPlus-Regular.ttf", size)  # Create a font object
    img = font.render(text, True, text_col)  # Render the text
    screen.blit(img, (x, y))  # Draw the text on the screen


def draw_text_wrap(text, text_col, x, y, max_width, size=100):
    font = pygame.font.Font(f"{prefix}assets/8bitOperatorPlus-Regular.ttf", size)  # Create a font object
    words = text.split(' ')  # Split the text into words
    lines = []
    current_line = ""
    
    for word in words:
        test_line = current_line + word + " "
        if font.size(test_line)[0] <= max_width:
            current_line = test_line
        else:
            lines.append(current_line)
            current_line = word + " "
    lines.append(current_line)  # Add the last line

    for i, line in enumerate(lines):
        img = font.render(line, True, text_col)  # Render the text
        screen.blit(img, (x, y + i * size))  # Draw the text on the screen








class Item:
    def __init__(self, name, image_path, type = "weapon", description = "none", value = 10, special = "none"):
        self.name = name
        self.image = pygame.image.load(image_path)
        self.image = pygame.transform.scale(self.image, (220, 220))
        self.type = type
        self.description = description
        self.value = value
        self.special = special

    def draw(self, x, y):
        screen.blit(self.image,((x*240)+70, (y*240)+210))


class Inventory:
    def __init__(self):
        self.items = []

    def add_item(self, item):
        self.items.append(item)

    def draw(self):
        global selectedTile
        pygame.draw.rect(screen, "BLACK",pygame.Rect(60, 200, 1200,720), 10)
        for x in range(5):
            for y in range(3):
                if (x*240)+60< mousePos[0] < (x*240)+300 and (y*240)+200< mousePos[1] < (y*240)+440:
                    pygame.draw.rect(screen, (252, 236, 3),pygame.Rect((x*240)+60, (y*240)+200, 240,240))
                    if mousePress[0]:
                        selectedTile = (x,y)

                if selectedTile == (x,y):
                    pygame.draw.rect(screen, "GREEN",pygame.Rect((x*240)+60, (y*240)+200, 240,240))


                pygame.draw.rect(screen, "BLACK",pygame.Rect((x*240)+60, (y*240)+200, 240,240), 10)

                if len(self.items) > x + (y*5):
                    (self.items[x + (y*5)]).draw(x,y)
                    if selectedTile == (x,y):
                        self.items[x + (y*5)].draw(5.2,0)
                        draw_text((str(self.items[x + (y*5)].type)).title(), "BLACK", 1600, 230, 70)
                        draw_text(str(self.items[x + (y*5)].value), "BLACK", 1600, 330, 70)
                        draw_text_wrap(str(self.items[x + (y*5)].description), "BLACK", 1400, 420, 500, 70)

        pygame.draw.rect(screen,"BLACK", pygame.Rect(1300,200,600,720), 10)


inventory = Inventory()

SwordItem = Item("Sword", f"{prefix}items/sword.png", "weapon", "Stabs the enemy", 10, "melee")
GunItem = Item("Gun", f"{prefix}items/gun.png", "weapon", "Shoots the enemy with love and cuddles", 10, "range")
WandItem = Item("Wand", f"{prefix}items/wand.png", "weapon", "Heh lets just say it uses dylans little cum monkeys", 10, "magic")

DogItem = Item("Dog", f"{prefix}items/dog.png", "item", "Pet him to gain health", 20, "health")
poisonBottle = Item("Poison B.", f"{prefix}items/bottle0.png", "item", "Weakens the enemy defense", 40, "enemyDefense")
weakenBottle = Item("Weakness B.", f"{prefix}items/bottle1.png", "item", "Makes the enemy attacks weaker", 40, "enemyAttack")
defenseBottle = Item("Defense B.", f"{prefix}items/bottle2.png", "item", "Makes your defense stronger", 40, "defense")
strengthBottle = Item("Strength B.", f"{prefix}items/bottle3.png", "item", "Makes your attacks stronger", 40, "strength")
LeanBottle = Item("Lean B.", f"{prefix}items/bottleOfLean.png", "item", "Be like pop smoke and have some lean", 50, "health")


inventory.add_item(DogItem)
inventory.add_item(SwordItem)
inventory.add_item(poisonBottle)
inventory.add_item(GunItem)
inventory.add_item(WandItem)
inventory.add_item(LeanBottle)



inventory.add_item(weakenBottle)
inventory.add_item(defenseBottle)
inventory.add_item(strengthBottle)

selectedTile = None


run = True
while run:
    key = pygame.key.get_pressed()

    if key[pygame.K_ESCAPE]:
        run = False    

    mousePos = pygame.mouse.get_pos()
    mousePress = pygame.mouse.get_pressed()

    screen.fill("WHITE")
    

    inventory.draw()

    #Final Lines Needed
    pygame.display.flip()
    clock.tick(60)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
            pass    
pygame.quit()