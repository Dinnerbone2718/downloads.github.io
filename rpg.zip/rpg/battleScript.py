import pygame
import os
import random

width = 1920
height = 1080

pygame.init()
pygame.mixer.init()

screen = pygame.display.set_mode((width,height))
clock = pygame.time.Clock()

volume = .5

def load_tiles(location):
    images = {}
    for filename in os.listdir(f"{location}"):  # Iterate over files in the tileset directory
        if filename.endswith(('.png', '.jpg', '.jpeg', '.bmp', '.gif')):  # Check for valid image extensions
            filepath = os.path.join(f"{location}", filename)  # Construct full file path
            image = pygame.image.load(filepath)  # Load the image
            key = os.path.splitext(filename)[0]  # Use the filename without extension as the key
            images[key] = image
    return images


def draw_text(text, text_col, x, y, size=100):
    font = pygame.font.Font(f"{prefix}assets/8bitOperatorPlus-Regular.ttf", size-90)  # Create a font object
    img = font.render(text, True, text_col)  # Render the text
    screen.blit(img, (x, y))  # Draw the text on the screen


script_dir = os.path.dirname(os.path.abspath(__file__))
prefix = f"{script_dir}/"

allUi = load_tiles(f"{prefix}uiAssets")



class combatClass:
    def __init__(self) -> None:
        self.playerIcon = pygame.transform.scale(allUi["playerIconBattle"], (520, 520))
        self.battleAnimationX = 0


        self.timer = 0

        self.enemyAnimation1 = pygame.transform.scale(allUi["blobIconBattle1"], (520, 520))
        self.enemyAnimation2 = pygame.transform.scale(allUi["blobIconBattle2"], (520, 520))
        self.enemyAnimationCount = 1
        self.currentEnemyAnimation = 1 
        self.enemyWeakness = "magic"
        self.enemyName = "Glorb"

        self.battleMusic = f"{prefix}music/battleMusicLight.mp3"

        self.enemyDefenseBuff = 1
        self.enemyAttackBuff = 1

        self.playerDefenseBuff = 1
        self.playerAttackBuff = 1

        self.tempDamage = 0

        self.enemyAnimationHit = 0
        self.playerAnimationHit = 0

        self.offsetInv = 0
        self.buttonCooldown = 0

        self.enemyMaxHealth = 150
        self.enemyTempHealth = 150
        self.enemyDefenseOdds = 20
        self.enemyAttackStrength = 10

        self.playerMaxHealth = 100
        self.playerTempHealth = 100

        self.battleWallpaper = pygame.transform.scale(allUi["battleWallpaper"], (1920, 1080)).convert()

        self.currentMenu = "start"

        pygame.mixer.music.load(self.battleMusic)
        pygame.mixer.music.set_volume(volume)
        pygame.mixer.music.play(-1)



    def reset(self, enemyAnimation1, enemyAnimation2, enemyWeakness, enemyName, enemyDefense, enemyAttack, enemyHealth, enemyDefenseOdds, enemyAttackStrength, battleMusic, battleWallpaper):
        self.enemyAnimation1 = pygame.transform.scale(allUi[enemyAnimation1], (520, 520))
        self.enemyAnimation2 = pygame.transform.scale(allUi[enemyAnimation2], (520, 520))
        self.enemyAnimationCount = 1
        self.currentEnemyAnimation = 1 
        self.enemyWeakness = enemyWeakness
        self.enemyName = enemyName

        self.battleMusic = f"{prefix}music/{battleMusic}.mp3"

        self.enemyDefenseBuff = enemyDefense
        self.enemyAttackBuff = enemyAttack

        self.playerDefenseBuff = 1
        self.playerAttackBuff = 1

        self.tempDamage = 0

        self.enemyAnimationHit = 0
        self.playerAnimationHit = 0

        self.offsetInv = 0
        self.buttonCooldown = 0

        self.enemyMaxHealth = enemyHealth
        self.enemyTempHealth = self.enemyMaxHealth
        self.enemyDefenseOdds = enemyDefenseOdds
        self.enemyAttackStrength = enemyAttackStrength

        self.playerMaxHealth = 100
        self.playerTempHealth = 100

        self.battleWallpaper = pygame.transform.scale(allUi[battleWallpaper], (1920, 1080)).convert()

        self.currentMenu = "start"
        
    def control(self, mousePos, mousePress):
        self.buttonCooldown += 1

        if mousePress[0] == True:
            if self.currentMenu == "start":
                self.offsetInv = 0
                if 1320 < mousePos[0] < 1820 and 900 < mousePos[1] < 1000:
                        self.currentMenu = "items"
                        self.buttonCooldown = 0
                    
                if 1320 < mousePos[0] < 1820 and 780 < mousePos[1] < 880:
                    self.currentMenu = "attack"
                    self.buttonCooldown = 0

            else:
                if mousePos[0] < 500 and mousePos[1] < 100:
                    self.currentMenu = "start"

                if (self.currentMenu == "attack" or self.currentMenu == "items") and self.buttonCooldown > 5:
                    if 1120 < mousePos[0] < 1720 and 660< mousePos[1] < 760:
                        self.offsetInv += 4
                        self.buttonCooldown = 0
                        if self.offsetInv > 15:
                            self.offsetInv = 12

                    if 520 < mousePos[0] < 1020 and 660< mousePos[1] < 760:
                        self.offsetInv -= 4
                        self.buttonCooldown = 0
                        if self.offsetInv < 0:
                            self.offsetInv = 0


                    self.count = 0
                    self.xOffset = 0
                    if self.currentMenu == "attack":
                        if self.buttonCooldown > 20:
                            for x in inventory.items[self.offsetInv:]:
                                if x.type == "weapon":
                                    if 520+self.xOffset < mousePos[0] < 1020+self.xOffset and 780+self.count < mousePos[1] < 880+self.count:
                                        self.currentMenu = None
                                        self.attack(x)
                                    self.count += 120
                                    if self.count == 240:
                                        self.count = 0
                                        self.xOffset += 600
                    elif self.currentMenu == "items":
                        if self.buttonCooldown > 20:
                            for x in inventory.items[self.offsetInv:]:
                                if x.type == "item":
                                    if 520+self.xOffset < mousePos[0] < 1020+self.xOffset and 780+self.count < mousePos[1] < 880+self.count:
                                        self.currentMenu = None
                                        self.attack(x)
                                    self.count += 120
                                    if self.count == 240:
                                        self.count = 0
                                        self.xOffset += 600                        


        pass

    def attack(self, item):
        print(item.name, item.type, item.value, item.special )
        if item.type == "item":
            if item.special == "health":
                self.playerTempHealth += item.value
            
            if item.special == "enemyDefense":
                self.enemyDefenseBuff -= item.value*.01
                if self.enemyDefenseBuff <= 0:
                    self.enemyDefenseBuff = .01

            if item.special == "enemyAttack":
                self.enemyAttackStrength -= item.value*.1
                if self.enemyAttackStrength < 0:
                    self.enemyAttackStrength = 0

            if item.special == "defense":
                self.playerDefenseBuff += item.value*.01

            if item.special == "strength":
                self.playerAttackBuff += item.value*.1

            self.tempDamage = 0
            self.aiTurn()
            inventory.items.remove(item)
        
        if item.type == "weapon":
            self.damageMultiplier = 1

            if item.special == self.enemyWeakness:
                if random.randint(0, 1) == 1:
                    self.damageMultiplier = 2
            else:
                if random.randint(0, 10) == 1:
                    self.damageMultiplier = 2   


            self.tempDamage = (item.value*self.damageMultiplier*self.playerAttackBuff)/self.enemyDefenseBuff

        self.decreaseAmount = self.tempDamage/30
            



    def aiTurn(self):

        if self.enemyTempHealth/self.enemyMaxHealth < .5:
            self.enemyDefenseOdds *= 1.2
            if self.enemyDefenseOdds > 90:
                self.enemyDefenseOdds = 90
        else:
            self.enemyDefenseOdds *= .6
        self.enemyDefenseOdds = round(self.enemyDefenseOdds)
        if random.randint(0,100) < self.enemyDefenseOdds:
            if random.randint(0,1) == 0: 
                self.enemyDefenseBuff *= 1.2
                self.textToDisplay = "Forcefield"
            else: 
                self.enemyTempHealth += round(self.enemyMaxHealth*.1)
                self.textToDisplay = "Heal"
        else:
            if random.randint(0,1) == 0: self.tempDamage = ((self.enemyAttackStrength * self.enemyAttackBuff)/self.playerDefenseBuff)*-1
            elif random.randint(0,1) == 0: 
                self.playerDefenseBuff *= .8 
                self.textToDisplay = "Confusion"
            else: 
                self.enemyAttackBuff *= 1.2
                self.textToDisplay = "Strength"
        if self.tempDamage != 0:
            self.decreaseAmount = self.tempDamage/30
            self.currentMenu = None
        else: 
            self.currentMenu = "enemy"
            self.timer = 0
        pass


    def end(self, winner):
        pygame.mixer.music.stop()
        print(f"Winner: {winner}")

    def draw(self, mousePos, mousePress):
        screen.blit(self.battleWallpaper, (0, 0))

        if self.enemyTempHealth < 1 and (self.currentMenu == "start" or self.currentMenu == "end"):
            self.currentMenu = "end"
            self.battleAnimationX = round((self.battleAnimationX-100)*.99)
            self.currentEnemyAnimation = 1
            self.winner = "player"

        if self.playerTempHealth < 1 and (self.currentMenu == "start" or self.currentMenu == "end"):
            self.currentMenu = "end"
            self.battleAnimationX = round((self.battleAnimationX-100)*.99)
            self.currentEnemyAnimation = 1
            self.winner = "enemy"

        if (self.enemyTempHealth < 1 or self.playerTempHealth < 1) and self.battleAnimationX < 5:
            self.end(self.winner)


        if self.currentMenu == "enemy":
            self.timer += 1

            draw_text(f"{self.enemyName} used {self.textToDisplay}", "GREY", 0,200- (self.timer**(self.timer/30)), 200)


            if self.timer > 60:
                self.timer = 0
                self.currentMenu = "start"





        ##Enemy Attack
        if self.tempDamage < 0:
            self.enemyAnimationHit = (self.enemyAnimationHit + 1)%5
            self.tempDamage -= self.decreaseAmount
            self.playerTempHealth += self.decreaseAmount

            if self.tempDamage > -0.1:
                self.decreaseAmount = 0
                self.tempDamage = 0
                self.enemyAnimationHit = 0
                self.currentMenu = "start"

        ##Player Attack-
        if self.tempDamage > 0:
            self.enemyAnimationHit = (self.enemyAnimationHit + 1)%5
            self.tempDamage -= self.decreaseAmount
            self.enemyTempHealth -= self.decreaseAmount
            if self.damageMultiplier == 2:
                draw_text("CRITICAL HIT", "BLACK", 60, 400-(self.enemyAnimationHit*20), 150)
            if self.tempDamage < 0.1:
                self.decreaseAmount = 0
                self.tempDamage = 0
                self.enemyAnimationHit = 0
                self.aiTurn()

        if self.battleAnimationX > 400:
            self.enemyAnimationCount += 1
            self.control(mousePos, mousePress)

        if self.enemyAnimationCount % 7 == 0:
            self.currentEnemyAnimation = 2 if self.currentEnemyAnimation == 1 else 1

        if self.battleAnimationX < 520:
            self.battleAnimationX += abs((self.battleAnimationX - 520) / 10)


        pygame.draw.rect(screen, "BLACK", pygame.Rect(self.battleAnimationX - 520, 560, self.playerMaxHealth * 5, 50))
        pygame.draw.rect(screen, "RED", pygame.Rect(self.battleAnimationX - 520, 560, (self.playerTempHealth / self.playerMaxHealth) * 500, 50))

        pygame.draw.rect(screen, "BLACK", pygame.Rect(1940 - self.battleAnimationX, 0, self.enemyMaxHealth * 5, 50))
        pygame.draw.rect(screen, "RED", pygame.Rect(1940 - self.battleAnimationX, 0, (self.enemyTempHealth / self.enemyMaxHealth) * 500, 50))

        enemy_image = self.enemyAnimation1 if self.currentEnemyAnimation == 1 else self.enemyAnimation2

        if self.enemyAnimationHit == 0 or self.tempDamage<0:
            screen.blit(enemy_image, (1895 - self.battleAnimationX, 0))
        elif self.enemyAnimationHit < 3 and self.tempDamage>0:
            screen.blit(enemy_image, (1875 - self.battleAnimationX, 0))
        elif self.tempDamage>0:
            screen.blit(enemy_image, (1915 - self.battleAnimationX, 0))




        if self.enemyAnimationHit == 0 or self.tempDamage>0:
            screen.blit(self.playerIcon, (self.battleAnimationX - 520, 560))
        elif self.enemyAnimationHit < 3 and self.tempDamage<0:
            screen.blit(self.playerIcon, (self.battleAnimationX - 550, 560))
        elif self.tempDamage<0:
            screen.blit(self.playerIcon, (self.battleAnimationX - 490, 560))



        if self.currentMenu != "start" and self.currentMenu != None and self.currentMenu !="enemy" and self.currentMenu !="end":
            self.draw_button(mousePos, 0, 0, "BACK", 120, -10)


        if self.currentMenu == "start":
            self.draw_button(mousePos, 1320, 780, "ATTACK", 1420, 770)
            self.draw_button(mousePos, 1320, 900, "ITEMS", 1450, 890)




        if self.currentMenu == "attack":
            self.count = 0
            self.xOffset = 0
            self.draw_button(mousePos, 1120, 660, "Next Page", 1160, 650)
            self.draw_button(mousePos, 520, 660, "Last Page", 540, 650)
            self.tempInv = []
            for x in inventory.items:
                if x.type == "weapon":
                    self.tempInv.append(x)

            for x in self.tempInv[self.offsetInv:]:
                if self.xOffset < 601:
                    self.draw_button(mousePos, 520+self.xOffset, 780+self.count, x.name, 620+self.xOffset, 770+self.count, (100,100,100, 128), (100,100,100,200))
                self.count += 120
                if self.count == 240:
                    self.count = 0
                    self.xOffset += 600

        elif self.currentMenu == "items":
            self.count = 0
            self.xOffset = 0
            self.draw_button(mousePos, 1120, 660, "Next Page", 1160, 650)
            self.draw_button(mousePos, 520, 660, "Last Page", 540, 650)
            self.tempInv = []
            for x in inventory.items:
                if x.type == "item":
                    self.tempInv.append(x)
            for x in self.tempInv[self.offsetInv:]:
                if self.xOffset < 601:
                    self.draw_button(mousePos, 520+self.xOffset, 780+self.count, x.name, 520+self.xOffset, 770+self.count, (100,100,100, 128), (100,100,100,200))
                self.count += 120
                if self.count == 240:
                    self.count = 0
                    self.xOffset += 600




    def draw_button(self, mousePos, x, y, text, text_x, text_y, darkFill = (200,200,200, 128), fill = (200, 200, 200, 200)):
        if x < mousePos[0] < x + 500 and y < mousePos[1] < y + 100:
            rect_color = darkFill
        else:
            rect_color = fill
        rect_surface = pygame.Surface((500, 100), pygame.SRCALPHA)
        rect_surface.fill(rect_color)
        screen.blit(rect_surface, (x, y))
        draw_text(text, "BLACK", text_x, text_y, 170)


class Item:
    def __init__(self, name, image_path, type = "weapon", description = "none", value = 10, special = "none"):
        self.name = name
        self.image = pygame.image.load(image_path)
        self.image = pygame.transform.scale(self.image, (220, 220))
        self.type = type
        self.description = description
        self.value = value
        self.special = special


    def draw(self, x, y):
        screen.blit(self.image,((x*240)+370, (y*240)+210))




class Inventory:
    def __init__(self):
        self.items = []
        self.selectedInvTile = None
    def add_item(self, item):
        self.items.append(item)
        self.mouseRelease = False
    def draw(self):
        pygame.draw.rect(screen, "WHITE",pygame.Rect(360, 200, 1200,720))
        for x in range(5):
            for y in range(3):
                if (x*240)+360< mousePos[0] < (x*240)+600 and (y*240)+200< mousePos[1] < (y*240)+440:
                    pygame.draw.rect(screen, (252, 236, 3),pygame.Rect((x*240)+360, (y*240)+200, 240,240))
                    if mousePress[0] and self.mouseRelease:
                        self.mouseRelease = False
                        if self.selectedInvTile == (x,y):
                            self.selectedInvTile = None
                        else:
                            self.selectedInvTile = (x,y)
                    elif mousePress[0] == False:
                        self.mouseRelease = True
                if self.selectedInvTile == (x,y):
                    pygame.draw.rect(screen, "GREEN",pygame.Rect((x*240)+360, (y*240)+200, 240,240))

                pygame.draw.rect(screen, "BLACK",pygame.Rect((x*240)+360, (y*240)+200, 240,240), 10)

                if len(self.items) > x + (y*5):
                    (self.items[x + (y*5)]).draw(x,y)


combat = combatClass()
inCombat = True


inventory = Inventory()

SwordItem = Item("Sword", f"{prefix}items/sword.png", "weapon", "Stabs the enemy", 10, "melee")
GunItem = Item("Gun", f"{prefix}items/gun.png", "weapon", "Shoots the enemy with love and cuddles", 10, "range")
WandItem = Item("Wand", f"{prefix}items/wand.png", "weapon", "Heh lets just say it uses dylans little cum monkeys", 10, "magic")

DogItem = Item("Dog", f"{prefix}items/dog.png", "item", "Pet him to gain health", 20, "health")
poisonBottle = Item("Poison B.", f"{prefix}items/bottle0.png", "item", "Weakens the enemy defense", 40, "enemyDefense")
weakenBottle = Item("Weakness B.", f"{prefix}items/bottle1.png", "item", "Makes the enemy attacks weaker", 40, "enemyAttack")
defenseBottle = Item("Defense B.", f"{prefix}items/bottle2.png", "item", "Makes your defense stronger", 40, "defense")
strengthBottle = Item("Strength B.", f"{prefix}items/bottle3.png", "item", "Makes your attacks stronger", 40, "strength")
LeanBottle = Item("Lean B.", f"{prefix}items/bottleOfLean.png", "item", "Be like pop smoke and have some lean", 50, "health")

inventory.add_item(DogItem)
inventory.add_item(SwordItem)
inventory.add_item(poisonBottle)
inventory.add_item(GunItem)
inventory.add_item(WandItem)
inventory.add_item(LeanBottle)



inventory.add_item(weakenBottle)
inventory.add_item(defenseBottle)
inventory.add_item(strengthBottle)


run = True
while run:
    key = pygame.key.get_pressed()

    if key[pygame.K_ESCAPE]:
        run = False    

    mousePos = pygame.mouse.get_pos()
    mousePress = pygame.mouse.get_pressed()

    screen.fill((200,100,100))
    
    if inCombat:
        combat.draw(mousePos, mousePress)

    #Final Lines Needed
    pygame.display.flip()
    clock.tick(30)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
            pass    
pygame.quit()