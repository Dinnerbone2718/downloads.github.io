import pygame
import pygame.scrap
import os
import ast
import math
import time
import re

# Initialize Pygame
pygame.init()


clock = pygame.time.Clock()  # Create an object to help track time

prefix = ""

class Tile:
    def __init__(self, x, y, tile, type, layer = 1, special = 'None') -> None:
        self.x = x
        self.y = y
        self.type = type
        self.tile = tile
        self.special = special
        self.image = allTiles[tile]
        self.image = pygame.transform.scale(self.image, (80,80))  # Scale the image to 40x40 pixels
        self.rect = self.image.get_rect()
        self.layer = layer
        if layer == 1:
            tilesL1.append(self)
            tilesL1OC.append((self.x, self.y))
        elif layer == 2:
            tilesL2.append(self)
            tilesL2OC.append((self.x, self.y))
        else:
            tilesL3.append(self)
            tilesL3OC.append((self.x, self.y))

        tiles.append(self)
        pass

    def draw(self):
        global xOff, yOff, showType, typing, tempText, selectedTile, selectedLayer, mousePress, mousePos
        self.rect.x = self.x + xOff  # Adjust x position with offset
        self.rect.y = self.y + yOff  # Adjust y position with offset
        if self.rect.x*80 > -20 and self.rect.x*80< 1920 and self.rect.y*80 > -20 and self.rect.y*80 < 920:
            screen.blit(self.image, (self.rect.x*80, self.rect.y*80))  # Draw the tile image
        else:
            return
        if showType:
            if self.type == allTileTypes[selectedTileType]:
                pygame.draw.rect(screen, "GREEN", pygame.Rect(self.rect.x*80, self.rect.y*80, 80,80))
        if self.layer == 1:
            if ((self.x, self.y) not in tilesL1OC):  
                tiles.remove(self)  
                tilesL1.remove(self)
        if self.layer == 2:
            if ((self.x, self.y) not in tilesL2OC):  
                tiles.remove(self)  
                tilesL2.remove(self)
        if self.layer == 3:
            if ((self.x, self.y) not in tilesL3OC):  
                tiles.remove(self)        
                tilesL3.remove(self)
        if selectedTile == None and selectedLayer == self.layer and mousePress[0] == True and mousePos[1] < 940 and typing == False:
            if mousePos[0] > self.rect.x*80 and mousePos[0] < (self.rect.x*80) + 80 and mousePos[1] > self.rect.y*80 and mousePos[1] < (self.rect.y*80) + 80:
                tempText = self.special
                typing = self

allLevels = []
tiles = []
selectedLayer = 1
selectedTileType = 0
tempText = ""

tilesL1 = []
tilesL2 = []
tilesL3 = []

tilesL1OC = []
tilesL2OC = []
tilesL3OC = []

allTileTypes = ["floor", "wall", "entity", "interationBox", "door"]
deltaTime = 1


def draw_text(text, text_col, x, y, size=100):
    # Remove null characters from the text
    text = text.replace('\x00', '')

    font = pygame.font.SysFont(None, size)  # Create a font object
    img = font.render(text, True, text_col)  # Render the text
    screen.blit(img, (x, y))  # Draw the text on the screen

def load_tiles():
    images = {}
    for filename in os.listdir(f"{prefix}tileset"):  # Iterate over files in the tileset directory
        if filename.endswith(('.png', '.jpg', '.jpeg', '.bmp', '.gif')):  # Check for valid image extensions
            filepath = os.path.join(f"{prefix}tileset", filename)  # Construct full file path
            image = pygame.image.load(filepath)  # Load the image
            key = os.path.splitext(filename)[0]  # Use the filename without extension as the key
            images[key] = image
    return images


with os.scandir(f"{prefix}levels") as entries:
    for level in entries:
        allLevels.append(level)
        print(level.name)  # Print the name of each level

userInput = input("Select level>>>")
selectedLevel = int(userInput) - 1

levelEdit = (allLevels[selectedLevel])

selectedTile = None
xOff = 0
yOff = 0
scrollOffset = 0
showType = False
typing = False

moveCount = 0

# Read the selected level file
with open(levelEdit.path, "r") as file:
    contents = (file.read())

if contents:
    print("Loaded")

else:
    print("No Data")

lists = re.findall(r'\[.*?\]', contents)

try:
    contentString = ast.literal_eval(lists[1])
    contentString2 = ast.literal_eval(lists[0])
except Exception as e:
    contentString = None
    print(e)
try:
    background = contentString2[0]
except: background = "BLACK"


allTiles = load_tiles()
allTileKeys = allTiles.keys()

if contentString:
    for x in contentString:
        Tile(x[0],x[1],x[2],x[3],x[4],x[5])

# Set up the display
screen_width, screen_height = 1920, 1080
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("RPG")

pygame.scrap.init()


# Main loop
running = True
while running:
    mousePos = pygame.mouse.get_pos()
    mousePress = pygame.mouse.get_pressed()

    for event in pygame.event.get():
        if event.type == pygame.KEYDOWN:
            if typing:
                if event.key == pygame.K_ESCAPE:
                    typing.special = tempText
                    typing = False
                elif event.key == pygame.K_BACKSPACE:
                    tempText = tempText[:-1]
                elif event.key == pygame.K_v and pygame.key.get_mods() & pygame.KMOD_CTRL:
                    # Handle pasting directly
                    if pygame.scrap.get(pygame.SCRAP_TEXT):
                        pasted_text = pygame.scrap.get(pygame.SCRAP_TEXT).decode('utf-8')
                        tempText += pasted_text
                else:
                    tempText += event.unicode

    key = pygame.key.get_pressed()  # Get the state of all keyboard keys
    # Fill the screen with a color (e.g., white)
    screen.fill(background)
    if key[pygame.K_1] == False:
        for x in tilesL1:
            x.draw()
    if key[pygame.K_2] == False:
        for x in tilesL2:
            x.draw()
    if key[pygame.K_3] == False:
        for x in tilesL3:
            x.draw()   
    if typing == False:
        if moveCount > 5:
            if key[pygame.K_a] or key[pygame.K_LEFT]:
                xOff += 1
                moveCount = 0
            if key[pygame.K_d] or key[pygame.K_RIGHT]:
                xOff -= 1
                moveCount = 0
            if key[pygame.K_w] or key[pygame.K_UP]:
                yOff += 1
                moveCount = 0
            if key[pygame.K_s] or key[pygame.K_DOWN]:
                yOff -= 1
                moveCount = 0
            if key[pygame.K_z]:
                selectedTileType -= 1
                if selectedTileType == -1:
                    selectedTileType = len(allTileTypes) -1
                moveCount = 0
            if key[pygame.K_x]:
                selectedTileType +=1
                if selectedTileType == len(allTileTypes):
                    selectedTileType = 0       
                moveCount = 0
        
        moveCount+=1*deltaTime
        if key[pygame.K_e]:
            scrollOffset -= 30*deltaTime
        if key[pygame.K_q]:
            scrollOffset += 30*deltaTime
        if key[pygame.K_1]:
            selectedLayer = 1
        if key[pygame.K_2]:
            selectedLayer = 2
        if key[pygame.K_3]:
            selectedLayer = 3

        showType = False
        if key[pygame.K_4]:
            showType = True


        if key[pygame.K_SPACE]:
            running = False

        if key[pygame.K_ESCAPE]:
            selectedTile = None
    

        if mousePress[0]:
            if mousePos[1] and selectedTile and mousePos[1]< 880:
                if selectedLayer == 1:
                    if (round((mousePos[0]-40)/80)-xOff,round((mousePos[1]-40)/80)-yOff) not in tilesL1OC:
                        Tile(round((mousePos[0]-40)/80)-xOff,round((mousePos[1]-40)/80)-yOff,selectedTileKey, allTileTypes[selectedTileType])
                if selectedLayer == 2:
                    if (round((mousePos[0]-40)/80)-xOff,round((mousePos[1]-40)/80)-yOff) not in tilesL2OC:
                        Tile(round((mousePos[0]-40)/80)-xOff,round((mousePos[1]-40)/80)-yOff,selectedTileKey, allTileTypes[selectedTileType], 2)
                if selectedLayer == 3:
                    if (round((mousePos[0]-40)/80)-xOff,round((mousePos[1]-40)/80)-yOff) not in tilesL3OC:
                        Tile(round((mousePos[0]-40)/80)-xOff,round((mousePos[1]-40)/80)-yOff,selectedTileKey, allTileTypes[selectedTileType], 3)
        if mousePress[2]:
                if selectedLayer == 1:
                    if (round((mousePos[0]-40)/80)-xOff,round((mousePos[1]-40)/80)-yOff) in tilesL1OC:
                        tilesL1OC.remove((round((mousePos[0]-40)/80)-xOff,round((mousePos[1]-40)/80)-yOff))
                if selectedLayer == 2:
                    if (round((mousePos[0]-40)/80)-xOff,round((mousePos[1]-40)/80)-yOff) in tilesL2OC:
                        tilesL2OC.remove((round((mousePos[0]-40)/80)-xOff,round((mousePos[1]-40)/80)-yOff))
                if selectedLayer == 3:
                    if (round((mousePos[0]-40)/80)-xOff,round((mousePos[1]-40)/80)-yOff) in tilesL3OC:
                        tilesL3OC.remove((round((mousePos[0]-40)/80)-xOff,round((mousePos[1]-40)/80)-yOff))

    else:
        pygame.draw.rect(screen, "GREY", pygame.Rect(200,340,1520, 400))
        draw_text(tempText, "BLACK", 220, 440,30)

    draw_text(str((round((mousePos[0]-40)/80)-xOff,round((mousePos[1]-40)/80)-yOff)), (0, 0, 0), 1620, 50)
    draw_text(f"Layer {selectedLayer}", (0, 0, 0), 1620, 120)
    draw_text(f"{allTileTypes[selectedTileType]}", (0, 0, 0), 1620, 190)
    draw_text(f"{round(clock.get_fps())}", (0, 0, 0), 1620, 260)
    try:
        deltaTime = 60/clock.get_fps()
    except: deltaTime = 1
    pygame.draw.rect(screen, (100,100,200), pygame.Rect(0, 880, 1920, 200))
    count = 0
    for key, tile in allTiles.items():
        count += 150
        image = pygame.transform.scale(tile, (120,120))
        if 0 + count + scrollOffset < 1920:
            if 0 + count + scrollOffset > -120:
                screen.blit(image, (0 + count + scrollOffset, 920))
                pygame.draw.rect(screen, "BLACK", pygame.Rect(count + scrollOffset, 920, 120, 120), 2)
        else: break
        if mousePress[0] and mousePos[1] > 940:
            if count + scrollOffset < mousePos[0] and count + scrollOffset + 120 > mousePos[0]:
                selectedTile = image
                selectedTileKey = key
          

    if selectedTile:
        screen.blit(selectedTile, (0, 0))

    # Update the display
    pygame.display.flip()
    clock.tick(60)
# Clean up

pygame.quit()

save = input("Save?")
print(background)
backgroundInput = input("background?")


if save == "y" or save == "Y":
    with open(levelEdit.path, "w") as file:
        tileData = [(x.x, x.y, x.tile, x.type, x.layer, x.special) for x in tiles]
        file.write(f"[{backgroundInput}]{tileData}")

