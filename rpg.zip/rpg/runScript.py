import pygame
import os
import ast
import math
import time
import re
import shutil
import random

# Initialize Pygame
pygame.init()
pygame.mixer.init()

volume = .2
clock = pygame.time.Clock()  # Create an object to help track time

script_dir = os.path.dirname(os.path.abspath(__file__))
prefix = f"{script_dir}/"


class combatFunctions:
    def __init__(self) -> None:
        pass

    def giveMoney(self, amout):
        global money
        money += amout

combatFunc = combatFunctions()


def giveItem(itemName):
    if itemName == "Trumpet":
        item = Item("Trumpet", f"{prefix}items/Trumpet.png", "weapon", "Trumpet that attakc with its shit ass music", 10, "music")
    inventory.add_item(item)


class combatClass:
    def __init__(self) -> None:
        self.playerIcon = pygame.transform.scale(allUi["playerIconBattle"], (520, 520))
        self.battleAnimationX = 0


        self.timer = 0

        self.enemyAnimation1 = pygame.transform.scale(allUi["blobIconBattle1"], (520, 520))
        self.enemyAnimation2 = pygame.transform.scale(allUi["blobIconBattle2"], (520, 520))
        self.enemyAnimationCount = 1
        self.currentEnemyAnimation = 1 
        self.enemyWeakness = "magic"
        self.enemyName = "Glorb"

        self.battleMusic = f"{prefix}music/battleMusicLight.mp3"

        self.enemyDefenseBuff = 1
        self.enemyAttackBuff = 1

        self.playerDefenseBuff = 1
        self.playerAttackBuff = 1

        self.tempDamage = 0

        self.enemyAnimationHit = 0
        self.playerAnimationHit = 0

        self.offsetInv = 0
        self.buttonCooldown = 0

        self.enemyMaxHealth = 150
        self.enemyTempHealth = 150
        self.enemyDefenseOdds = 20
        self.enemyAttackStrength = 10

        self.playerMaxHealth = 100
        self.playerTempHealth = 100

        self.battleWallpaper = pygame.transform.scale(allUi["battleWallpaper"], (1920, 1080)).convert()

        self.currentMenu = "start"




    def reset(self, enemyAnimation1, enemyAnimation2, enemyWeakness, enemyName, enemyDefense, enemyAttack, enemyHealth, enemyDefenseOdds, enemyAttackStrength, battleMusic, battleWallpaper, endFunction, winText, lossText):
        self.enemyAnimation1 = pygame.transform.scale(allUi[enemyAnimation1], (520, 520))
        self.enemyAnimation2 = pygame.transform.scale(allUi[enemyAnimation2], (520, 520))
        self.enemyAnimationCount = 1
        self.currentEnemyAnimation = 1 
        self.enemyWeakness = enemyWeakness
        self.enemyName = enemyName

        self.battleMusic = f"{prefix}music/{battleMusic}.mp3"

        self.enemyDefenseBuff = enemyDefense
        self.enemyAttackBuff = enemyAttack

        self.playerDefenseBuff = 1
        self.playerAttackBuff = 1
        
        self.endFuntion = endFunction
        self.winText = winText
        self.lossText = lossText


        self.tempDamage = 0

        self.enemyAnimationHit = 0
        self.playerAnimationHit = 0

        self.offsetInv = 0
        self.buttonCooldown = 0

        self.enemyMaxHealth = enemyHealth
        self.enemyTempHealth = self.enemyMaxHealth
        self.enemyDefenseOdds = enemyDefenseOdds
        self.enemyAttackStrength = enemyAttackStrength

        self.playerMaxHealth = 100
        self.playerTempHealth = 100

        self.battleWallpaper = pygame.transform.scale(allUi[battleWallpaper], (1920, 1080)).convert()

        self.currentMenu = "start"
        pygame.mixer.music.load(self.battleMusic)
        pygame.mixer.music.set_volume(volume)
        pygame.mixer.music.play(-1)

    def control(self, mousePos, mousePress):
        self.buttonCooldown += 1

        if mousePress[0] == True:
            if self.currentMenu == "start":
                self.offsetInv = 0
                if 1320 < mousePos[0] < 1820 and 900 < mousePos[1] < 1000:
                        self.currentMenu = "items"
                        self.buttonCooldown = 0
                    
                if 1320 < mousePos[0] < 1820 and 780 < mousePos[1] < 880:
                    self.currentMenu = "attack"
                    self.buttonCooldown = 0

            else:
                if mousePos[0] < 500 and mousePos[1] < 100:
                    self.currentMenu = "start"

                if (self.currentMenu == "attack" or self.currentMenu == "items") and self.buttonCooldown > 5:
                    if 1120 < mousePos[0] < 1720 and 660< mousePos[1] < 760:
                        self.offsetInv += 4
                        self.buttonCooldown = 0
                        if self.offsetInv > 15:
                            self.offsetInv = 12

                    if 520 < mousePos[0] < 1020 and 660< mousePos[1] < 760:
                        self.offsetInv -= 4
                        self.buttonCooldown = 0
                        if self.offsetInv < 0:
                            self.offsetInv = 0


                    self.count = 0
                    self.xOffset = 0
                    if self.currentMenu == "attack":
                        if self.buttonCooldown > 20:
                            for x in inventory.items[self.offsetInv:]:
                                if x.type == "weapon":
                                    if 520+self.xOffset < mousePos[0] < 1020+self.xOffset and 780+self.count < mousePos[1] < 880+self.count:
                                        self.currentMenu = None
                                        self.attack(x)
                                    self.count += 120
                                    if self.count == 240:
                                        self.count = 0
                                        self.xOffset += 600
                    elif self.currentMenu == "items":
                        if self.buttonCooldown > 20:
                            for x in inventory.items[self.offsetInv:]:
                                if x.type == "item":
                                    if 520+self.xOffset < mousePos[0] < 1020+self.xOffset and 780+self.count < mousePos[1] < 880+self.count:
                                        self.currentMenu = None
                                        self.attack(x)
                                    self.count += 120
                                    if self.count == 240:
                                        self.count = 0
                                        self.xOffset += 600                        


        pass

    def attack(self, item):
        print(item.name, item.type, item.value, item.special )
        if item.type == "item":
            if item.special == "health":
                self.playerTempHealth += item.value
            
            if item.special == "enemyDefense":
                self.enemyDefenseBuff -= item.value*.01
                if self.enemyDefenseBuff <= 0:
                    self.enemyDefenseBuff = .01

            if item.special == "enemyAttack":
                self.enemyAttackStrength -= item.value*.1
                if self.enemyAttackStrength < 0:
                    self.enemyAttackStrength = 0

            if item.special == "defense":
                self.playerDefenseBuff += item.value*.01

            if item.special == "strength":
                self.playerAttackBuff += item.value*.1

            self.tempDamage = 0
            self.aiTurn()
            inventory.items.remove(item)
        
        if item.type == "weapon":
            self.damageMultiplier = 1

            if item.special == self.enemyWeakness:
                if random.randint(0, 1) == 1:
                    self.damageMultiplier = 2
            else:
                if random.randint(0, 10) == 1:
                    self.damageMultiplier = 2   


            self.tempDamage = (item.value*self.damageMultiplier*self.playerAttackBuff)/self.enemyDefenseBuff

        self.decreaseAmount = self.tempDamage/30
            



    def aiTurn(self):

        if self.enemyTempHealth/self.enemyMaxHealth < .5:
            self.enemyDefenseOdds *= 1.2
            if self.enemyDefenseOdds > 90:
                self.enemyDefenseOdds = 90
        else:
            self.enemyDefenseOdds *= .6
        self.enemyDefenseOdds = round(self.enemyDefenseOdds)
        if random.randint(0,100) < self.enemyDefenseOdds:
            if random.randint(0,1) == 0: 
                self.enemyDefenseBuff *= 1.2
                self.textToDisplay = "Forcefield"
            else: 
                self.enemyTempHealth += round(self.enemyMaxHealth*.1)
                self.textToDisplay = "Heal"
        else:
            if random.randint(0,1) == 0: self.tempDamage = ((self.enemyAttackStrength * self.enemyAttackBuff)/self.playerDefenseBuff)*-1
            elif random.randint(0,1) == 0: 
                self.playerDefenseBuff *= .8 
                self.textToDisplay = "Confusion"
            else: 
                self.enemyAttackBuff *= 1.2
                self.textToDisplay = "Strength"
        if self.tempDamage != 0:
            self.decreaseAmount = self.tempDamage/30
            self.currentMenu = None
        else: 
            self.currentMenu = "enemy"
            self.timer = 0
        pass


    def end(self, winner):
        global xOff, yOff, player, running, tilesL1, tilesL2, tilesL3, tilesL1OC, tilesL2OC, tilesL3OC, wallList, prefix, background, drawText, textToDraw, currentLevelPath, tiles, money, inBattle, levelWalkInCord
        pygame.mixer.music.stop()

        global inBattle, textToDraw, drawText

        inBattle = False

        if winner == "player":
            textToDraw = RPGText(str(self.winText), "BLACK", (600,440,720, 200), 0.025, 60)
            endFunc = f"combatFunc.{self.endFuntion}"
            print(endFunc)
            eval(endFunc)
        else:
            textToDraw = RPGText(str(self.lossText), "BLACK", (600,440,720, 200), 0.025, 60)
            player.x, player.y = levelWalkInCord

            drawText = True
            print(f"Winner: {winner}")
            tiles = []

            tilesL1 = []
            tilesL2 = []
            tilesL3 = []

            tilesL1OC = []
            tilesL2OC = []
            tilesL3OC = []

            wallList = []
            

            for x in range((len(tiles)*2)):
                for tempTile in tiles:
                    tempTile.draw()
                for tempTile in tilesL1:
                    tempTile.draw()
                for tempTile in tilesL2:
                    tempTile.draw()
                for tempTile in tilesL3:
                    tempTile.draw()
            
            with open(currentLevelPath, "r") as file:
                contents = (file.read())

            print(currentLevelPath)


            lists = re.findall(r'\[.*?\]', contents)

            try:
                contentString = ast.literal_eval(lists[1])
                contentString2 = ast.literal_eval(lists[0])
            except:
                contentString = None

            try:
                background = contentString2[0]
            except: background = "BLACK"

            if contentString:
                for x in contentString:
                    Tile(x[0],x[1],x[2],x[3],x[4],x[5])

                    
            self.isMoving = False
            xOff, yOff = round(xOff), round(yOff)
        

    def draw(self, mousePos, mousePress):
        screen.blit(self.battleWallpaper, (0, 0))

        if self.enemyTempHealth < 1 and (self.currentMenu == "start" or self.currentMenu == "end"):
            self.currentMenu = "end"
            self.battleAnimationX = round((self.battleAnimationX-100)*.99)
            self.currentEnemyAnimation = 1
            self.winner = "player"

        if self.playerTempHealth < 1 and (self.currentMenu == "start" or self.currentMenu == "end"):
            self.currentMenu = "end"
            self.battleAnimationX = round((self.battleAnimationX-100)*.99)
            self.currentEnemyAnimation = 1
            self.winner = "enemy"

        if (self.enemyTempHealth < 1 or self.playerTempHealth < 1) and self.battleAnimationX < 5:
            self.end(self.winner)


        if self.currentMenu == "enemy":
            self.timer += 1

            draw_text(f"{self.enemyName} used {self.textToDisplay}", "GREY", 0,200- (self.timer**(self.timer/30)), 110)


            if self.timer > 60:
                self.timer = 0
                self.currentMenu = "start"





        ##Enemy Attack
        if self.tempDamage < 0:
            self.enemyAnimationHit = (self.enemyAnimationHit + 1)%5
            self.tempDamage -= self.decreaseAmount
            self.playerTempHealth += self.decreaseAmount

            if self.tempDamage > -0.1:
                self.decreaseAmount = 0
                self.tempDamage = 0
                self.enemyAnimationHit = 0
                self.currentMenu = "start"

        ##Player Attack-
        if self.tempDamage > 0:
            self.enemyAnimationHit = (self.enemyAnimationHit + 1)%5
            self.tempDamage -= self.decreaseAmount
            self.enemyTempHealth -= self.decreaseAmount
            if self.damageMultiplier == 2:
                draw_text("CRITICAL HIT", "BLACK", 60, 400-(self.enemyAnimationHit*20), 60)
            if self.tempDamage < 0.1:
                self.decreaseAmount = 0
                self.tempDamage = 0
                self.enemyAnimationHit = 0
                self.aiTurn()

        if self.battleAnimationX > 400:
            self.enemyAnimationCount += 1
            self.control(mousePos, mousePress)

        if self.enemyAnimationCount % 7 == 0:
            self.currentEnemyAnimation = 2 if self.currentEnemyAnimation == 1 else 1

        if self.battleAnimationX < 520:
            self.battleAnimationX += abs((self.battleAnimationX - 520) / 10)


        pygame.draw.rect(screen, "BLACK", pygame.Rect(self.battleAnimationX - 520, 560, 500, 50))
        pygame.draw.rect(screen, "RED", pygame.Rect(self.battleAnimationX - 520, 560, (self.playerTempHealth / self.playerMaxHealth) * 500, 50))

        pygame.draw.rect(screen, "BLACK", pygame.Rect(1940 - self.battleAnimationX, 0, 500, 50))
        pygame.draw.rect(screen, "RED", pygame.Rect(1940 - self.battleAnimationX, 0, (self.enemyTempHealth / self.enemyMaxHealth) * 500, 50))

        enemy_image = self.enemyAnimation1 if self.currentEnemyAnimation == 1 else self.enemyAnimation2

        if self.enemyAnimationHit == 0 or self.tempDamage<0:
            screen.blit(enemy_image, (1895 - self.battleAnimationX, 0))
        elif self.enemyAnimationHit < 3 and self.tempDamage>0:
            screen.blit(enemy_image, (1875 - self.battleAnimationX, 0))
        elif self.tempDamage>0:
            screen.blit(enemy_image, (1915 - self.battleAnimationX, 0))




        if self.enemyAnimationHit == 0 or self.tempDamage>0:
            screen.blit(self.playerIcon, (self.battleAnimationX - 520, 560))
        elif self.enemyAnimationHit < 3 and self.tempDamage<0:
            screen.blit(self.playerIcon, (self.battleAnimationX - 550, 560))
        elif self.tempDamage<0:
            screen.blit(self.playerIcon, (self.battleAnimationX - 490, 560))



        if self.currentMenu != "start" and self.currentMenu != None and self.currentMenu !="enemy" and self.currentMenu !="end":
            self.draw_button(mousePos, 0, 0, "BACK", 120, -10)


        if self.currentMenu == "start":
            self.draw_button(mousePos, 1320, 780, "ATTACK", 1420, 770)
            self.draw_button(mousePos, 1320, 900, "ITEMS", 1450, 890)




        if self.currentMenu == "attack":
            self.count = 0
            self.xOffset = 0
            self.draw_button(mousePos, 1120, 660, "Next Page", 1160, 650)
            self.draw_button(mousePos, 520, 660, "Last Page", 540, 650)
            self.tempInv = []
            for x in inventory.items:
                if x.type == "weapon":
                    self.tempInv.append(x)

            for x in self.tempInv[self.offsetInv:]:
                if self.xOffset < 601:
                    self.draw_button(mousePos, 520+self.xOffset, 780+self.count, x.name, 520+self.xOffset, 770+self.count, (100,100,100, 128), (100,100,100,200))
                self.count += 120
                if self.count == 240:
                    self.count = 0
                    self.xOffset += 600

        elif self.currentMenu == "items":
            self.count = 0
            self.xOffset = 0
            self.draw_button(mousePos, 1120, 660, "Next Page", 1160, 650)
            self.draw_button(mousePos, 520, 660, "Last Page", 540, 650)
            self.tempInv = []
            for x in inventory.items:
                if x.type == "item":
                    self.tempInv.append(x)
            for x in self.tempInv[self.offsetInv:]:
                if self.xOffset < 601:
                    self.draw_button(mousePos, 520+self.xOffset, 780+self.count, x.name, 520+self.xOffset, 770+self.count, (100,100,100, 128), (100,100,100,200))
                self.count += 120
                if self.count == 240:
                    self.count = 0
                    self.xOffset += 600




    def draw_button(self, mousePos, x, y, text, text_x, text_y, darkFill = (200,200,200, 128), fill = (200, 200, 200, 200)):
        if x < mousePos[0] < x + 500 and y < mousePos[1] < y + 100:
            rect_color = darkFill
        else:
            rect_color = fill
        rect_surface = pygame.Surface((500, 100), pygame.SRCALPHA)
        rect_surface.fill(rect_color)
        screen.blit(rect_surface, (x, y))
        draw_text(text, "BLACK", text_x, text_y, 80)


class Item:
    def __init__(self, name, image_path, type = "weapon", description = "none", value = 10, special = "none"):
        self.name = name
        self.image = pygame.image.load(image_path)
        self.image = pygame.transform.scale(self.image, (220, 220))
        self.type = type
        self.description = description
        self.value = value
        self.special = special



    def draw(self, x, y):
        screen.blit(self.image,((x*240)+70, (y*240)+210))


class Inventory:
    def __init__(self):
        self.items = []
        self.selectedTile = (0,0)
    def add_item(self, item):
        self.items.append(item)

    def draw(self):
        pygame.draw.rect(screen, "WHITE",pygame.Rect(60, 200, 1200,720))
        pygame.draw.rect(screen,"WHITE", pygame.Rect(1300,200,600,720))
        pygame.draw.rect(screen, "BLACK",pygame.Rect(60, 200, 1200,720), 10)
        for x in range(5):
            for y in range(3):
                if (x*240)+60< mousePos[0] < (x*240)+300 and (y*240)+200< mousePos[1] < (y*240)+440:
                    pygame.draw.rect(screen, (252, 236, 3),pygame.Rect((x*240)+60, (y*240)+200, 240,240))
                    if mousePress[0]:
                        self.selectedTile = (x,y)

                if self.selectedTile == (x,y):
                    pygame.draw.rect(screen, "GREEN",pygame.Rect((x*240)+60, (y*240)+200, 240,240))


                pygame.draw.rect(screen, "BLACK",pygame.Rect((x*240)+60, (y*240)+200, 240,240), 10)

                if len(self.items) > x + (y*5):
                    (self.items[x + (y*5)]).draw(x,y)
                    if self.selectedTile == (x,y):
                        self.items[x + (y*5)].draw(5.2,0)
                        draw_text((str(self.items[x + (y*5)].type)).title(), "BLACK", 1600, 230, 70)
                        draw_text(str(self.items[x + (y*5)].value), "BLACK", 1600, 330, 70)
                        draw_text_wrap(str(self.items[x + (y*5)].description), "BLACK", 1400, 420, 500, 70)

        pygame.draw.rect(screen,"BLACK", pygame.Rect(1300,200,600,720), 10)


class RPGText:
    def __init__(self, text, color, rect, typing_speed=0.05, size=20, rectColor = (200,200,200)):
        self.text = text
        self.font = pygame.font.Font(f"{prefix}assets/8bitOperatorPlus-Regular.ttf", size)  # Create a font object
        self.color = color
        self.rect = pygame.Rect(rect)
        self.typing_speed = typing_speed

        self.rectColor = rectColor
        self.current_text = ""
        self.index = 0
        self.finished = False
        self.last_update = time.time()

    def draw_text(self):
        pygame.draw.rect(screen, self.rectColor, self.rect)
        pygame.draw.rect(screen, "BLACK", self.rect, 20)
        lines = self.wrap_text(self.current_text)
        total_height = len(lines) * self.font.get_height()
        start_y = self.rect.y + (self.rect.height - total_height) // 2
        
        for i, line in enumerate(lines):
            text_surface = self.font.render(line, True, self.color)
            text_rect = text_surface.get_rect()
            text_rect.centerx = self.rect.centerx
            text_rect.y = start_y + i * self.font.get_height()
            screen.blit(text_surface, text_rect.topleft)

    def update(self):
        if not self.finished:
            if time.time() - self.last_update > self.typing_speed:
                self.index += 1
                self.current_text = self.text[:self.index]
                self.last_update = time.time()

                if self.index >= len(self.text):
                    self.finished = True

    def wrap_text(self, text):
        words = text.split()
        lines = []
        current_line = ""

        for word in words:
            test_line = current_line + word + " "
            if self.font.size(test_line)[0] < self.rect.width:
                current_line = test_line
            else:
                lines.append(current_line.strip())
                current_line = word + " "

        lines.append(current_line.strip())
        return lines
    
    def skip(self):
        self.finished = True
        self.current_text = self.text






class Tile:
    def __init__(self, x, y, tile, type, layer=1, special='None') -> None:
        self.x = round(x)
        self.y = round(y)
        self.type = type
        self.tile = tile
        self.special = special
        self.image = pygame.transform.scale(allTiles[tile], (120, 120))
        self.rect = self.image.get_rect()
        self.layer = layer



        if type == "wall":
            wallList.append((self.x, self.y))


        layer_list = {
            1: (tilesL1, tilesL1OC),
            2: (tilesL2, tilesL2OC),
            3: (tilesL3, tilesL3OC)
        }

        layer_list[self.layer][0].append(self)
        layer_list[self.layer][1].append((self.x, self.y))

        tiles.append(self)
        if self.type == "entity":
            self.moveCounter = random.randrange(0,70)
            self.isMoving = False
            self.moveAnimation = 0
            self.dir = 0
            self.cooldown = random.randrange(60,120)
            self.data = ast.literal_eval(self.special)
            self.targetLocation = None
            temp = []
            self.animations = load_tiles(f"{prefix}entitySprites/{self.data['sprites']}")
            for name in self.animations:
                temp.append(pygame.transform.scale(self.animations[name], (120, 120)))
            self.animations = temp

    def draw(self):
        global xOff, yOff, player, running, tilesL1, tilesL2, tilesL3, tilesL1OC, tilesL2OC, tilesL3OC, wallList, prefix, background, drawText, textToDraw, currentLevelPath, tiles, money, inBattle, levelWalkInCord
        self.rect.x = self.x + xOff
        self.rect.y = self.y + yOff
        rect_x120 = self.rect.x * 120
        rect_y120 = self.rect.y * 120
        
        if self.type == "entity":

            if self.data["move"] == "True":
                rect_x120, rect_y120 = (((self.x + xOff)*120, (self.y + yOff)*120))
                self.moveCounter += 1
                if self.moveCounter % 5 == 0:
                    self.moveAnimation+=1
                    self.moveAnimation = self.moveAnimation%3
                if self.moveCounter > self.cooldown:
                    if self.targetLocation == None:
                        self.moveAnimation = 0
                        self.targetLocation = [random.randint(-1,1), random.randint(-1,1)]


                        if self.targetLocation[0] != None and self.targetLocation[1] != None:
                            remove = random.randint(0,1)
                            self.targetLocation[remove] = 0

                        if ((self.x + self.targetLocation[0], self.y)) in wallList:
                            self.targetLocation[0] = 0


                        if ((self.x, self.y+self.targetLocation[1])) in wallList:
                            self.targetLocation[1] = 0
                        
                        if self.targetLocation[0] != 0 or self.targetLocation[1] != 0: 
                            self.moveCounter = 0
                        else:
                            self.targetLocation = None 

                elif self.targetLocation != None:
                    tilesL3OC.remove((self.x, self.y))

                    if self.targetLocation[0] > 0:
                        self.targetLocation[0] -= .05
                        self.x += .05
                        self.dir = 6
                    if self.targetLocation[0] < 0:
                        self.targetLocation[0] += .05
                        self.x -= .05
                        self.dir = 3
                    if self.targetLocation[1] > 0:
                        self.targetLocation[1] -= .05
                        self.y += .05
                        self.dir = 0
                    if self.targetLocation[1] < 0:
                        self.targetLocation[1] += .05
                        self.y -= .05
                        self.dir = 9



                    self.x = round(self.x, 3)
                    self.y = round(self.y, 3)
                    self.targetLocation[0] = round(self.targetLocation[0], 3)
                    self.targetLocation[1] = round(self.targetLocation[1], 3)

                    if self.targetLocation[0] == 0 and self.targetLocation[1] == 0:
                        self.targetLocation = None
                        self.moveAnimation = 1

                    self.image = self.animations[self.dir + self.moveAnimation]
                    tilesL3OC.append((self.x, self.y))
            else:
                self.moveCounter+=1
                if self.moveCounter % 10 == 0:
                    self.moveAnimation+=1
                    self.moveAnimation = self.moveAnimation%2
                self.image = self.animations[self.dir + self.moveAnimation]

        if -20 < rect_x120 < 1920 and -20 < rect_y120 < 1080:
            if self.tile!="sprite_010":
                screen.blit(self.image, (rect_x120, rect_y120))
        else:
            return
        try:
            if self.layer == 1 and (self.x, self.y) not in tilesL1OC:
                tiles.remove(self)
                tilesL1.remove(self)
            elif self.layer == 2 and (self.x, self.y) not in tilesL2OC:
                tiles.remove(self)
                tilesL2.remove(self)
            elif self.layer == 3 and (self.x, self.y) not in tilesL3OC:
                tiles.remove(self)
                tilesL3.remove(self)
        except: pass

        if player.x == self.x and player.y == self.y and self.type == "interationBox":
            print(self.special)
            data = ast.literal_eval(self.special)
            if data["type"] == "update":
                levelWalkInCord = (player.x, player.y)
            if data["type"] == "speech":
                drawText = True
                textToDraw = RPGText(str(data["text"]), "BLACK", (600,440,720, 200), 0.025, 60)

            if data["type"] in "itemFind":
                drawText = True
                textToDraw = RPGText(str(data["text"]), "BLACK", (600,440,720, 200), 0.025, 60, (255, 225, 0))

            if data["type"] == "giveItem":
                giveItem(data["giveItem"]) 

            if "battle" in data:
                battleDetails = data["battle"]
                inBattle = True
                combat.reset(battleDetails[0], battleDetails[1], battleDetails[2], battleDetails[3], battleDetails[4], battleDetails[5], battleDetails[6], battleDetails[7], battleDetails[8], battleDetails[9], battleDetails[10], battleDetails[11], battleDetails[12], battleDetails[13])

            if data["type"] == "money":
                money+=data["amount"]

            if data["delete"] != None:
                deleteList = ast.literal_eval(data["delete"])

                for deleteObject in deleteList:
                    if deleteObject[2] == 1:
                        for tile in tilesL1:
                            if deleteObject[0] == tile.x and deleteObject[1] == tile.y:
                                tilesL1OC.remove((deleteObject[0],deleteObject[1]))
                                tiles.remove(tile)
                                tilesL1.remove(tile)

                    if deleteObject[2] == 2:
                        for tile in tilesL2:
                            if deleteObject[0] == tile.x and deleteObject[1] == tile.y:
                                tilesL2OC.remove((deleteObject[0],deleteObject[1]))
                                tiles.remove(tile)
                                tilesL2.remove(tile)
                                if tile.type == "wall":
                                    wallList.remove((deleteObject[0],deleteObject[1]))


                    if deleteObject[2] == 3:
                        for tile in tilesL3:
                            if deleteObject[0] == tile.x and deleteObject[1] == tile.y:
                                tilesL3OC.remove((deleteObject[0],deleteObject[1]))
                                tiles.remove(tile)
                                tilesL3.remove(tile)

        if player.x == self.x and player.y == self.y and self.type == "door":
            data = ast.literal_eval(self.special)
            location = data["location"]
            cords = data["cords"]
            if "camOffset" in data:
                xOff, yOff = data["camOffset"]

            with open(currentLevelPath, "w") as file:
                tileData = [(x.x, x.y, x.tile, x.type, x.layer, x.special) for x in tiles]
                file.write(f"[{background}]{tileData}") 


            tiles = []

            tilesL1 = []
            tilesL2 = []
            tilesL3 = []

            tilesL1OC = []
            tilesL2OC = []
            tilesL3OC = []

            wallList = []

            player.x = cords[0]
            player.y = cords[1]
            
            levelWalkInCord = (player.x, player.y)

            for x in range((len(tiles)*2)):
                for tempTile in tiles:
                    tempTile.draw()
                for tempTile in tilesL1:
                    tempTile.draw()
                for tempTile in tilesL2:
                    tempTile.draw()
                for tempTile in tilesL3:
                    tempTile.draw()

            
            currentLevelPath = f"{prefix}runTimeMaps/{location}"

            # Read the selected level file
            with open(currentLevelPath, "r") as file:
                contents = (file.read())

            print(currentLevelPath)


            lists = re.findall(r'\[.*?\]', contents)

            try:
                contentString = ast.literal_eval(lists[1])
                contentString2 = ast.literal_eval(lists[0])
            except:
                contentString = None

            try:
                background = contentString2[0]
            except: background = "BLACK"

            if contentString:
                for x in contentString:
                    Tile(x[0],x[1],x[2],x[3],x[4],x[5])

                    
            self.isMoving = False
            xOff, yOff = round(xOff), round(yOff)

class Player:
    def __init__(self, animationFolder, x, y) -> None:
        global xOff, yOff
        self.spritesUnmod = load_tiles(prefix+animationFolder)
        self.sprites = []
        for key, defintion in self.spritesUnmod.items():
            resizedImage = pygame.transform.scale(defintion, (120, 120))
            self.sprites.append(resizedImage)

        self.moveAnimation = 1
        self.dir = 0
        self.animationCount = 0

        self.x = x 
        self.y = y 
        self.isMoving = False
        self.hitbox = pygame.Rect(0,0,120,120)
        pass


    def draw(self):
        global xOff, yOff
        self.hitbox.x, self.hitbox.y = (self.x+xOff)*120, (self.y+yOff)*120

        screen.blit(self.sprites[self.moveAnimation%3+self.dir], (self.hitbox.x, self.hitbox.y))

        if (self.hitbox.x<120 or self.hitbox.x>1800 or self.hitbox.y < 120 or self.hitbox.y>960)and self.isMoving == False:
            xOff, yOff = (self.x*-1)+8, (self.y*-1)+5

    def move(self, key):
        global xOff, yOff



        if self.isMoving == False:
            self.x = round(self.x)
            self.y = round(self.y)
            if key[pygame.K_a]:
                if ((self.x - 1, self.y)) not in wallList:
                    self.isMoving = [-1, 0]
                    self.dir = 3
            elif key[pygame.K_d]:
                if ((self.x + 1, self.y)) not in wallList:
                    self.isMoving = [1, 0]
                    self.dir = 6
            elif key[pygame.K_w]:
                if ((self.x, self.y-1)) not in wallList:
                    self.isMoving = [0, -1]
                    self.dir = 9
            elif key[pygame.K_s]:
                if ((self.x, self.y+1)) not in wallList:
                    self.isMoving = [0, 1]
                    self.dir = 0
            else:
                self.moveAnimation = 1
       
            if key[pygame.K_UP]:
                yOff += 1
            if key[pygame.K_DOWN]:
                yOff -= 1
            if key[pygame.K_LEFT]:
                xOff += 1
            if key[pygame.K_RIGHT]:
                xOff -= 1
        else:
            if self.isMoving[0] > 0:
                self.isMoving[0] = (int(round((self.isMoving[0]-.1)*10))/10)
                self.x += 0.1
            elif self.isMoving[0] < 0:
                self.isMoving[0] = (int(round((self.isMoving[0]+.1)*10))/10)
                self.x -= 0.1

            elif self.isMoving[1] > 0:
                self.isMoving[1] = (int(round((self.isMoving[1]-.1)*10))/10)
                self.y += 0.1
            elif self.isMoving[1] < 0:
                self.isMoving[1] = (int(round((self.isMoving[1]+.1)*10))/10)
                self.y -= 0.1
            self.animationCount += 1
            if self.animationCount == 4:
                self.moveAnimation += 1
                self.animationCount = 0
        
        if self.isMoving == [0, 0]:
            self.isMoving = False


allLevels = []
tiles = []


tilesL1 = []
tilesL2 = []
tilesL3 = []

tilesL1OC = []
tilesL2OC = []
tilesL3OC = []

wallList = []

displayedTextList = []


drawText = False

allTileTypes = ["floor", "wall", "entity", "interationBox", "door"]

inBattle = False

deltaTime = 1
inventoryOpen = False

inventory = Inventory()

slingShot = Item("Slingshot", f"{prefix}items/slingshot.png", "weapon", "Was just kinda in the your back pocket", 2, "range")

inventory.add_item(slingShot)


deltaButtomPress = 0

levelWalkInCord = (0,0)


def draw_text_wrap(text, text_col, x, y, max_width, size=100):
    font = pygame.font.Font(f"{prefix}assets/8bitOperatorPlus-Regular.ttf", size)  # Create a font object
    words = text.split(' ')  # Split the text into words
    lines = []
    current_line = ""
    
    for word in words:
        test_line = current_line + word + " "
        if font.size(test_line)[0] <= max_width:
            current_line = test_line
        else:
            lines.append(current_line)
            current_line = word + " "
    lines.append(current_line)  # Add the last line

    for i, line in enumerate(lines):
        img = font.render(line, True, text_col)  # Render the text
        screen.blit(img, (x, y + i * size))  # Draw the text on the screen





def draw_text(text, text_col, x, y, size=100):
    font = pygame.font.Font(f"{prefix}assets/8bitOperatorPlus-Regular.ttf", size)  # Create a font object
    img = font.render(text, True, text_col)  # Render the text
    screen.blit(img, (x, y))  # Draw the text on the screen

def load_tiles(location):
    images = {}
    for filename in os.listdir(f"{location}"):  # Iterate over files in the tileset directory
        if filename.endswith(('.png', '.jpg', '.jpeg', '.bmp', '.gif')):  # Check for valid image extensions
            filepath = os.path.join(f"{location}", filename)  # Construct full file path
            image = pygame.image.load(filepath)  # Load the image
            key = os.path.splitext(filename)[0]  # Use the filename without extension as the key
            images[key] = image
    return images


for file in os.listdir(f"{prefix}levels"):
    sourceFile = os.path.join(f"{prefix}levels", file)
    destinationFile = os.path.join(f"{prefix}runTimeMaps", file)

    shutil.copyfile(sourceFile, destinationFile)

with os.scandir(f"{prefix}runTimeMaps") as entries:
    for level in entries:
        allLevels.append(level)
        print(level.name)  # Print the name of each level

#userInput = input("Select level>>>")
userInput = 4
selectedLevel = int(userInput) - 1

levelEdit = (allLevels[selectedLevel])

xOff = 0
yOff = -2


# Read the selected level file
with open(levelEdit.path, "r") as file:
    contents = (file.read())

currentLevelPath = levelEdit.path

if contents:
    print("Loaded")

else:
    print("No Data")

lists = re.findall(r'\[.*?\]', contents)

contentString = ast.literal_eval(lists[1])
contentString2 = ast.literal_eval(lists[0])


try:
    background = contentString2[0]
except: background = "BLACK"


allTiles = load_tiles(f"{prefix}tileset")
allTileKeys = allTiles.keys()




if contentString:
    for x in contentString:
        Tile(x[0],x[1],x[2],x[3],x[4],x[5])









##Builds UI


allUi = load_tiles(f"{prefix}uiAssets")


freakCoinIcon = pygame.transform.scale(allUi["freakCoin"], (120, 120))



money = 0





def uiDraw():
    screen.blit(freakCoinIcon, (20,20))
    draw_text(f"{str(money)}¶", (100,255,100), 150, 20, 90)






# Set up the display
screen_width, screen_height = 1920, 1080
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("RPG")



player = Player("player", 3, 6)

combat = combatClass()

# Main loop
running = True
while running:
    mousePos = pygame.mouse.get_pos()
    mousePress = pygame.mouse.get_pressed()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    key = pygame.key.get_pressed()  # Get the state of all keyboard keys

    if key[pygame.K_ESCAPE]:
        running = False

    if inBattle == True and drawText == False:
        combat.draw(mousePos, mousePress)
        


    else:
        deltaButtomPress += 1

        if drawText == False and inventoryOpen == False:
            player.move(key)

        if key[pygame.K_e] and deltaButtomPress > 10:
            inventoryOpen = not inventoryOpen
            deltaButtomPress = 0


        # Fill the screen with a color (e.g., white)
        screen.fill(background)
        for x in tilesL1:
            x.draw()
        for x in tilesL2:
            x.draw()
        player.draw()
        for x in tilesL3:
            x.draw()   

        if drawText:
            textToDraw.update()
            textToDraw.draw_text()
            if key[pygame.K_SPACE]:
                drawText = False
                textToDraw.skip()

        draw_text(str((round(round((mousePos[0]-60)/120)-xOff), round(round((mousePos[1]-60)/120)-yOff))), (0, 0, 0), 1520, 50)
        draw_text(f"{round(clock.get_fps())}", (0, 0, 0), 1520, 150)
        draw_text(str((round(xOff), round(yOff))), (0, 0, 0), 1520, 250)
        try:
            deltaTime = 60/clock.get_fps()
        except: deltaTime = 1

        if inventoryOpen:
            inventory.draw()


        uiDraw()

    # Update the display
    pygame.display.flip()
    clock.tick(30)
# Clean up

pygame.quit()
